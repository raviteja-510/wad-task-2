function validateLogin() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
  
    // Basic validation, you should implement proper authentication logic on the server
    if (username === 'demo' && password === 'password') {
      alert('Login successful!'); // Replace this with actual login logic
      return true;
    } else {
      alert('Invalid credentials. Please try again.');
      return false;
    }
  }
  